# Átividade Prática de Programação para Interfaceamento de Hardware e Software

## 1. Introdução e Objetivos

Este trabalho prático tem como o objetivo demonstrar a integração entre:

- Módulos e bibliotecas de funções escritas na linguagem C,
- Código fonte de alto nível (Javascript, Lua ou Python) embutido via interpretador em
uma aplicação escrita na linguagem C e
- Código fonte de alto nível (Javascript, Lua ou Python) estendido através de novas
funcionalidades implementadas via chamada de funções escritas na linguagem C.

Parar alcançar estes objetivos pretende construir um programa em python que execute o algoritmo de levenshtein, construído em linguagem C. Para estabelecer esta relação foi construido o arquivo library.c que utiliza as bibliotecas pocketpy.h e pocketpy.c, as quais trazem as funcionalidades necessárias para fazer a associação entre os arquivos python e C.